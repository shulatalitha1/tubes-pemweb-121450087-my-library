# backend/project_name/views.py

from pyramid.view import view_config
from pyramid.response import Response
from pyramid.httpexceptions import HTTPOk, HTTPNotFound, HTTPBadRequest
from sqlalchemy.exc import DBAPIError, IntegrityError # Import IntegrityError
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, joinedload
import json
import os
from paste.deploy.loadwsgi import appconfig

# Pastikan semua model yang dibutuhkan diimpor
from .models import User, Book, Author

# Ini mungkin tidak lagi diperlukan jika Anda menghapus semua fitur autentikasi
# dari frontend dan backend, tapi tidak apa-apa jika tetap ada untuk sementara.
from .security import generate_token, JWT_SECRET, verify_password

# --- FUNGSI UNTUK MENDAPATKAN SESI DATABASE SECARA MANUAL ---
# Ini diperlukan karena Anda tidak menggunakan pyramid_tm
def get_db_session_manual():
    config_uri = 'development.ini'
    # Perbaikan path agar lebih robust, memastikan config dicari dari root proyek
    # yang berisi development.ini
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    full_config_uri = 'config:' + config_uri
    settings = appconfig(full_config_uri, relative_to=project_root)
    database_url = settings.get('sqlalchemy.url')
    if not database_url:
        raise ValueError("Tidak ditemukan 'sqlalchemy.url' dalam konfigurasi database.")
    engine = create_engine(database_url)
    Session = sessionmaker(bind=engine)
    return Session() # Mengembalikan instance sesi

# --- FUNGSI UNTUK CORS (add_cors_headers) ---
from pyramid.events import NewRequest, subscriber

@subscriber(NewRequest)
def add_cors_headers(event):
    """Add CORS headers to all responses"""
    request = event.request
    
    # Handle OPTIONS request immediately (preflight)
    if request.method == 'OPTIONS':
        response = HTTPOk()
        response.headers.update({
            'Access-Control-Allow-Origin': 'http://localhost:3000',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization, X-Requested-With',
            'Access-Control-Allow-Credentials': 'true',
            'Access-Control-Max-Age': '1728000',
        })
        # Raise the response to short-circuit request processing
        raise response
    
    # For non-OPTIONS requests, add CORS headers via callback
    def cors_callback(request, response):
        response.headers.update({
            'Access-Control-Allow-Origin': 'http://localhost:3000',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization, X-Requested-With',
            'Access-Control-Allow-Credentials': 'true',
        })
    
    request.add_response_callback(cors_callback)

# --- Views Umum ---
@view_config(route_name='home', renderer='json')
def home_view(request):
    return {'project': 'perpustakaan-digital', 'message': 'Welcome to the digital library API!'}

@view_config(route_name='status', renderer='json')
def status_view(request):
    return {'status': 'OK', 'message': 'Service is running.'}

# View ini tetap di sini, meskipun permission 'authenticated_access' tidak berlaku
# karena kebijakan autentikasi dinonaktifkan
@view_config(route_name='protected', renderer='json', permission='authenticated_access')
def protected_view(request):
    userid = request.authenticated_userid
    return {'message': f'Anda mengakses rute terproteksi! Authenticated User ID: {userid}', 'data': 'Data sensitif.'}

# --- Views untuk Buku ---
@view_config(route_name='books', renderer='json', request_method='GET')
def get_books(request):
    session = None
    try:
        session = get_db_session_manual()
        # Menggunakan joinedload untuk memuat relasi Author bersamaan
        books = session.query(Book).options(joinedload(Book.author)).all()
        
        # Logika serialisasi sudah ada di book.to_dict(), ini harusnya aman
        books_data = [book.to_dict() for book in books]
        
        return books_data
    except DBAPIError as e:
        print(f"DEBUG: Database Error in get_books: {e}") # Debug log
        return Response(str(e), status=500)
    except Exception as e:
        print(f"DEBUG: General Error in get_books: {e}") # Debug log
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        # Pastikan sesi ditutup di sini, bahkan jika ada error
        if session:
            session.close()

@view_config(route_name='book_detail', renderer='json', request_method='GET')
def get_book_detail(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi book_id ke integer ---
        book_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Book ID format. ID must be an integer.'})

    try:
        session = get_db_session_manual()
        book = session.query(Book).options(joinedload(Book.author)).filter_by(id=book_id).first()
        if book:
            return book.to_dict()
        return HTTPNotFound(json_body={'message': 'Buku tidak ditemukan'})
    except DBAPIError as e:
        print(f"DEBUG: Database Error in get_book_detail: {e}")
        return Response(str(e), status=500)
    except Exception as e:
        print(f"DEBUG: General Error in get_book_detail: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='books', renderer='json', request_method='POST')
def add_book(request):
    data = request.json_body
    session = None
    try:
        session = get_db_session_manual()
        
        author_id = data.get('author_id')
        # Jika author_id tidak disediakan tapi author_name disediakan, cari atau buat penulis baru
        if author_id is None and 'author_name' in data:
            author_name = data['author_name']
            author = session.query(Author).filter_by(name=author_name).first()
            if author:
                author_id = author.id
            else:
                new_author = Author(name=author_name, bio=data.get('author_bio'))
                session.add(new_author)
                session.flush() # Flush untuk mendapatkan ID penulis baru sebelum dipakai di Book
                author_id = new_author.id
        
        # Pastikan author_id ada atau berikan pesan kesalahan jika tidak ada
        if not author_id:
            # Perbaikan: Menggunakan HTTPBadRequest
            return HTTPBadRequest(json_body={'message': 'Author ID atau Author Name harus disediakan.'})

        new_book = Book(
            title=data['title'],
            isbn=data.get('isbn'),
            publication_year=data.get('publication_year'),
            author_id=author_id
        )
        session.add(new_book)
        session.commit() # <--- PASTIKAN ADA COMMIT UNTUK MENYIMPAN
        return Response(json_body={'message': 'Buku berhasil ditambahkan', 'book_id': new_book.id}, status=201)
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in add_book: {e}")
        # Perbaikan: Mengembalikan Response yang lebih spesifik
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except KeyError as e:
        # Tangani jika field 'title' atau 'author_id' wajib tidak ada
        if session:
            session.rollback()
        return HTTPBadRequest(json_body={'message': f'Missing required field: {e}'})
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in add_book: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='book_detail', renderer='json', request_method='PUT')
def update_book(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi book_id ke integer ---
        book_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Book ID format. ID must be an integer.'})

    data = request.json_body
    try:
        session = get_db_session_manual()
        book = session.query(Book).filter_by(id=book_id).first()
        
        if not book:
            return HTTPNotFound(json_body={'message': 'Buku tidak ditemukan'})
        
        # Update book fields
        book.title = data.get('title', book.title)
        book.isbn = data.get('isbn', book.isbn)
        book.publication_year = data.get('publication_year', book.publication_year)
        
        # Handle author update
        if 'author_id' in data:
            # --- PERBAIKAN DI SINI: Pastikan author_id yang diterima juga integer jika dari data ---
            try:
                book.author_id = int(data['author_id'])
            except ValueError:
                return HTTPBadRequest(json_body={'message': 'Invalid Author ID format in request body.'})
        elif 'author_name' in data:
            author_name = data['author_name']
            author = session.query(Author).filter_by(name=author_name).first()
            if author:
                book.author_id = author.id
            else:
                new_author = Author(name=author_name, bio=data.get('author_bio'))
                session.add(new_author)
                session.flush()
                book.author_id = new_author.id
        
        session.commit()
        return Response(json_body={'message': 'Buku berhasil diperbarui', 'book_id': book.id}, status=200)
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in update_book: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in update_book: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='book_detail', renderer='json', request_method='DELETE')
def delete_book(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi book_id ke integer ---
        book_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Book ID format. ID must be an integer.'})

    try:
        session = get_db_session_manual()
        book = session.query(Book).filter_by(id=book_id).first()
        
        if not book:
            return HTTPNotFound(json_body={'message': 'Buku tidak ditemukan'})
        
        session.delete(book)
        session.commit()
        return Response(json_body={'message': 'Buku berhasil dihapus'}, status=200)
    except IntegrityError as e: # Tangani IntegrityError secara spesifik
        if session:
            session.rollback()
        print(f"DEBUG: Integrity Error in delete_book: {e}")
        return Response(json_body={'message': 'Tidak dapat menghapus buku karena masih ada data terkait (misal: peminjaman).'}, status=409)
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in delete_book: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in delete_book: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

# --- Views untuk Authors ---
@view_config(route_name='authors', renderer='json', request_method='GET')
def get_authors(request):
    session = None
    try:
        session = get_db_session_manual()
        authors = session.query(Author).all()
        
        # Pastikan Anda mengembalikan data dari database
        authors_data = [author.to_dict() for author in authors]
        
        return authors_data
    except DBAPIError as e:
        print(f"DEBUG: Database Error in get_authors: {e}")
        return Response(str(e), status=500)
    except Exception as e:
        print(f"DEBUG: General Error in get_authors: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='author_detail', renderer='json', request_method='GET')
def get_author_detail(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi author_id ke integer ---
        author_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Author ID format. ID must be an integer.'})

    try:
        session = get_db_session_manual()
        author = session.query(Author).filter_by(id=author_id).first()
        if author:
            return author.to_dict()
        return HTTPNotFound(json_body={'message': 'Penulis tidak ditemukan'})
    except DBAPIError as e:
        print(f"DEBUG: Database Error in get_author_detail: {e}")
        return Response(str(e), status=500)
    except Exception as e:
        print(f"DEBUG: General Error in get_author_detail: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='authors', renderer='json', request_method='POST')
def add_author(request):
    data = request.json_body
    session = None
    try:
        session = get_db_session_manual()
        new_author = Author(name=data['name'], bio=data.get('bio')) # Gunakan .get() untuk bio
        session.add(new_author)
        session.commit() # <--- PASTIKAN ADA COMMIT UNTUK MENYIMPAN
        return Response(json_body={'message': 'Penulis berhasil ditambahkan', 'author_id': new_author.id}, status=201)
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in add_author: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except KeyError as e:
        if session:
            session.rollback()
        return HTTPBadRequest(json_body={'message': f'Missing required field: {e}'})
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in add_author: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='author_detail', renderer='json', request_method='PUT')
def update_author(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi author_id ke integer ---
        author_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Author ID format. ID must be an integer.'})

    data = request.json_body
    try:
        session = get_db_session_manual()
        author = session.query(Author).filter_by(id=author_id).first()
        
        if not author:
            return HTTPNotFound(json_body={'message': 'Penulis tidak ditemukan'})
        
        # Update author fields
        author.name = data.get('name', author.name)
        author.bio = data.get('bio', author.bio)
        
        session.commit()
        return Response(json_body={'message': 'Penulis berhasil diperbarui', 'author_id': author.id}, status=200)
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in update_author: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in update_author: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='author_detail', renderer='json', request_method='DELETE')
def delete_author(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi author_id ke integer ---
        author_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Author ID format. ID must be an integer.'})

    try:
        session = get_db_session_manual()
        author = session.query(Author).filter_by(id=author_id).first()
        
        if not author:
            return HTTPNotFound(json_body={'message': 'Penulis tidak ditemukan'})
        
        # Check if author has books
        books_count = session.query(Book).filter_by(author_id=author_id).count()
        if books_count > 0:
            # Perbaikan: Menggunakan HTTPBadRequest atau HTTPConflict jika Anda mau
            return HTTPBadRequest(json_body={'message': f'Tidak dapat menghapus penulis karena masih memiliki {books_count} buku'})
        
        session.delete(author)
        session.commit()
        return Response(json_body={'message': 'Penulis berhasil dihapus'}, status=200)
    except IntegrityError as e: # Tangani IntegrityError secara spesifik
        if session:
            session.rollback()
        print(f"DEBUG: Integrity Error in delete_author: {e}")
        return Response(json_body={'message': 'Tidak dapat menghapus penulis karena ada data terkait (misal: buku yang terhubung).'}, status=409) # HTTPConflict
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in delete_author: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in delete_author: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

# --- Views untuk Peminjaman dan Pengembalian (jika diperlukan) ---
# Hapus 'permission' jika tidak ada login
@view_config(route_name='borrow_book', renderer='json', request_method='POST')
def borrow_book_view(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi book_id ke integer ---
        book_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Book ID format. ID must be an integer.'})

    try:
        session = get_db_session_manual()
        book = session.query(Book).filter_by(id=book_id).first()
        if book:
            # Contoh logika: Anda bisa menambahkan kolom is_borrowed di model Book
            # book.is_borrowed = True
            session.commit()
            return Response(json_body={'message': f'Buku {book_id} berhasil dipinjam'}, status=200)
        return HTTPNotFound(json_body={'message': 'Buku tidak ditemukan'})
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in borrow_book: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in borrow_book: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()

@view_config(route_name='return_book', renderer='json', request_method='POST')
def return_book_view(request):
    session = None
    try:
        # --- PERBAIKAN DI SINI: Konversi book_id ke integer ---
        book_id = int(request.matchdict['id'])
    except ValueError:
        return HTTPBadRequest(json_body={'message': 'Invalid Book ID format. ID must be an integer.'})

    try:
        session = get_db_session_manual()
        book = session.query(Book).filter_by(id=book_id).first()
        if book:
            # Contoh logika: book.is_borrowed = False
            session.commit()
            return Response(json_body={'message': f'Buku {book_id} berhasil dikembalikan'}, status=200)
        return HTTPNotFound(json_body={'message': 'Buku tidak ditemukan'})
    except DBAPIError as e:
        if session:
            session.rollback()
        print(f"DEBUG: Database Error in return_book: {e}")
        return Response(json_body={'message': f'Database error: {e.args[0]}'}, status=500)
    except Exception as e:
        if session:
            session.rollback()
        print(f"DEBUG: General Error in return_book: {e}")
        return Response(f"Terjadi kesalahan: {e}", status=500)
    finally:
        if session:
            session.close()