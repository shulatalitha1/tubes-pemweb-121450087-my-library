# backend/project_name/models.py
from sqlalchemy import (
    Column,
    Integer,
    Text,
    String,
    ForeignKey,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import (
    scoped_session,
    sessionmaker,
    relationship
)
from zope.sqlalchemy import register # <-- Perubahan di sini, ZopeTransactionEvents tidak perlu diimpor langsung jika hanya pakai register
from passlib.context import CryptContext

# PERBAIKAN DI SINI:
# 1. Hapus 'extension=ZopeTransactionEvents()' dari sessionmaker
# 2. Tambahkan panggilan 'register(DBSession)' setelah DBSession dibuat
DBSession = scoped_session(sessionmaker()) # <-- Baris ini sekarang tanpa 'extension'
register(DBSession) # <-- BARIS BARU INI UNTUK Mendaftarkan event secara terpisah

Base = declarative_base()

# Konteks untuk hashing password
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class User(Base):
    """ Model untuk entitas Pengguna. """
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(128), nullable=False)
    role = Column(String(20), default='user') # Contoh peran: 'admin', 'user'

    def __init__(self, username, password, role='user'):
        self.username = username
        self.password_hash = pwd_context.hash(password)
        self.role = role

    def verify_password(self, password):
        """ Memverifikasi password yang diberikan dengan hash yang tersimpan. """
        return pwd_context.verify(password, self.password_hash)

    def to_dict(self):
        """ Mengubah objek User menjadi dictionary. """
        return {
            'id': self.id,
            'username': self.username,
            'role': self.role
        }

class Author(Base):
    """ Model untuk entitas Penulis. """
    __tablename__ = 'authors'
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    bio = Column(Text)

    books = relationship("Book", back_populates="author")

    def to_dict(self):
        """ Mengubah objek Author menjadi dictionary. """
        return {
            'id': self.id,
            'name': self.name,
            'bio': self.bio
        }

class Book(Base):
    """ Model untuk entitas Buku. """
    __tablename__ = 'books'
    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    isbn = Column(String(20), unique=True)
    publication_year = Column(Integer)
    author_id = Column(Integer, ForeignKey('authors.id'))

    author = relationship("Author", back_populates="books")

    def to_dict(self):
        """ Mengubah objek Book menjadi dictionary. """
        return {
            'id': self.id,
            'title': self.title,
            'isbn': self.isbn,
            'publication_year': self.publication_year,
            'author_id': self.author_id,
            'author_name': self.author.name if self.author else None
        }