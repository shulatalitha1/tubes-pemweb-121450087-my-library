import React from 'react';
// Menggunakan Link, Routes, Route untuk navigasi dan routing
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

// Menghapus import LoginForm karena tidak lagi digunakan
// Menghapus AuthProvider dan useAuth karena tidak ada lagi autentikasi
// import { AuthProvider, useAuth } from './components/AuthContext';
// import LoginForm from './components/LoginForm';

// Mengimpor komponen lain yang masih digunakan
import BookList from './components/BookList';
import BookForm from './components/BookForm';
import AuthorList from './components/AuthorList';
import AuthorForm from './components/AuthorForm';

// Menghapus komponen PrivateRoute karena tidak ada lagi rute yang dilindungi
// const PrivateRoute = ({ children }) => {
//   const { isAuthenticated } = useAuth();
//   return isAuthenticated ? children : <Navigate to="/login" replace />;
// };

const App = () => {
  return (
    <Router>
      {/* Menghapus AuthProvider karena tidak ada lagi konteks autentikasi */}
      {/* <AuthProvider> */}
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex flex-col">
          <NavBar />
          <main className="flex-grow container mx-auto p-4 md:p-8">
            <Routes>
              {/* Menghapus rute /login */}
              {/* <Route path="/login" element={<LoginForm />} /> */}

              {/* Semua rute sekarang dapat diakses langsung tanpa PrivateRoute */}
              <Route path="/" element={<Home />} />
              <Route path="/books" element={<BookList />} />
              <Route path="/books/add" element={<BookForm />} />
              <Route path="/books/edit/:id" element={<BookForm />} />
              <Route path="/authors" element={<AuthorList />} />
              <Route path="/authors/add" element={<AuthorForm />} />
              <Route path="/authors/edit/:id" element={<AuthorForm />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
      {/* </AuthProvider> */}
    </Router>
  );
};

const NavBar = () => {
  // Menghapus penggunaan useAuth karena tidak ada lagi autentikasi
  // const { isAuthenticated, logout } = useAuth();

  return (
    <nav className="bg-white shadow-md py-4 px-6 rounded-b-xl">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-indigo-700 hover:text-indigo-900 transition duration-300">
          <i className="fas fa-book-reader mr-2"></i>Perpustakaan
        </Link>
        <ul className="flex space-x-6">
          {/* Menghapus kondisi autentikasi, selalu tampilkan link navigasi */}
          {/* {isAuthenticated ? ( */}
            <>
              <li>
                <Link to="/books" className="text-gray-700 hover:text-indigo-600 font-medium transition duration-300">
                  <i className="fas fa-book mr-1"></i>Buku
                </Link>
              </li>
              <li>
                <Link to="/authors" className="text-gray-700 hover:text-indigo-600 font-medium transition duration-300">
                  <i className="fas fa-user-edit mr-1"></i>Penulis
                </Link>
              </li>
              {/* Menghapus tombol Keluar karena tidak ada login */}
              {/* <li>
                <button
                  onClick={logout}
                  className="text-red-600 hover:text-red-800 font-medium transition duration-300"
                >
                  <i className="fas fa-sign-out-alt mr-1"></i>Keluar
                </button>
              </li> */}
            </>
          {/* ) : ( */}
            {/* Menghapus link Masuk karena tidak ada login */}
            {/* <li>
              <Link to="/login" className="text-gray-700 hover:text-indigo-600 font-medium transition duration-300">
                <i className="fas fa-sign-in-alt mr-1"></i>Masuk
              </Link>
            </li> */}
          {/* )} */}
        </ul>
      </div>
    </nav>
  );
};

const Home = () => {
  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-180px)] text-center">
      <h1 className="text-5xl font-extrabold text-gray-800 mb-6 animate-fade-in-down">
        Selamat Datang di Perpustakaan Digital
      </h1>
      <p className="text-xl text-gray-600 mb-8 max-w-2xl animate-fade-in-up delay-200">
        Kelola koleksi buku dan data penulis Anda dengan mudah dan efisien.
      </p>
      <div className="flex space-x-4 animate-fade-in-up delay-400">
        <Link
          to="/books"
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-full shadow-lg transition duration-300 transform hover:scale-105 flex items-center"
        >
          <i className="fas fa-book mr-2"></i>Lihat Buku
        </Link>
        <Link
          to="/authors"
          className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-full shadow-lg transition duration-300 transform hover:scale-105 flex items-center"
        >
          <i className="fas fa-user-edit mr-2"></i>Lihat Penulis
        </Link>
      </div>
    </div>
  );
};

const NotFound = () => {
  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-180px)] text-center">
      <h1 className="text-6xl font-bold text-red-600 mb-4">404</h1>
      <p className="text-2xl text-gray-700 mb-6">Halaman Tidak Ditemukan</p>
      <Link to="/" className="text-indigo-600 hover:underline text-lg">
        Kembali ke Beranda
      </Link>
    </div>
  );
};

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-4 text-center rounded-t-xl mt-8">
      <p>&copy; {new Date().getFullYear()} Perpustakaan Digital. Hak Cipta Dilindungi.</p>
    </footer>
  );
};

export default App;