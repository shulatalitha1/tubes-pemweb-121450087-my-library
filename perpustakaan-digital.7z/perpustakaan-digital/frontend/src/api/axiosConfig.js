// frontend/src/api/axiosConfig.js
import axios from 'axios';

// URL dasar untuk API backend Anda
// Pastikan ini menunjuk ke alamat dan port tempat backend Pyramid Anda berjalan (biasanya 6543)
const API_BASE_URL = 'http://localhost:6543/api'; 

const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json', // Menentukan tipe konten untuk permintaan
  },
  // 'withCredentials' tidak diperlukan jika Anda tidak menangani cookie atau sesi berbasis kredensial
  // Jika sebelumnya Anda memiliki ini diatur ke true, menghapusnya atau mengaturnya ke false adalah praktik yang baik
  // withCredentials: false, 
});

// Interceptor autentikasi telah DIHAPUS
// karena aplikasi ini tidak lagi menggunakan fitur login/autentikasi.
// Ini akan membuat kode lebih bersih dan menghindari upaya yang tidak perlu untuk membaca token.

export default axiosInstance;