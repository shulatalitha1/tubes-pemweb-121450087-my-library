import React, { useState, useEffect } from 'react';
import axios from '../api/axiosConfig';
import { useNavigate, useParams } from 'react-router-dom';

const AuthorForm = () => {
  const { id } = useParams(); // Untuk mode edit
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const isEditMode = Boolean(id);

  useEffect(() => {
    if (isEditMode) {
      const fetchAuthor = async () => {
        try {
          const response = await axios.get(`/authors/${id}`);
          const authorData = response.data;
          setName(authorData.name);
          setBio(authorData.bio || '');
        } catch (err) {
          console.error('Gagal mengambil penulis:', err);
          setError('Gagal memuat detail penulis. Silakan coba lagi.');
        } finally {
          setLoading(false);
        }
      };
      fetchAuthor();
    } else {
      setLoading(false);
    }
  }, [id, isEditMode]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const authorData = { name, bio };

    try {
      if (isEditMode) {
        await axios.put(`/authors/${id}`, authorData);
        setSuccessMessage('Penulis berhasil diperbarui!');
      } else {
        await axios.post('/authors', authorData);
        setSuccessMessage('Penulis berhasil ditambahkan!');
        // Reset form setelah penambahan
        setName('');
        setBio('');
      }
      setTimeout(() => navigate('/authors'), 1500); // Kembali ke daftar setelah 1.5 detik
    } catch (err) {
      console.error('Gagal menyimpan penulis:', err.response ? err.response.data : err.message);
      setError(err.response?.data || 'Gagal menyimpan penulis. Pastikan nama terisi.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-500"></div>
        <p className="ml-4 text-lg text-gray-700">Memuat formulir...</p>
      </div>
    );
  }

  if (error && !successMessage) {
    return <div className="text-red-600 text-center text-lg mt-8">{error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200 w-full max-w-xl mx-auto">
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        {isEditMode ? 'Edit Penulis' : 'Tambah Penulis Baru'}
      </h2>
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md relative mb-4" role="alert">
          <strong className="font-bold">Berhasil!</strong>
          <span className="block sm:inline ml-2">{successMessage}</span>
        </div>
      )}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-4" role="alert">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline ml-2">{error}</span>
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-gray-700 text-sm font-medium mb-2">
            Nama Penulis:
          </label>
          <input
            type="text"
            id="name"
            className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="bio" className="block text-gray-700 text-sm font-medium mb-2">
            Biografi:
          </label>
          <textarea
            id="bio"
            rows="4"
            className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
            value={bio}
            onChange={(e) => setBio(e.target.value)}
          ></textarea>
        </div>
        <div className="flex justify-end space-x-4 mt-6">
          <button
            type="button"
            onClick={() => navigate('/authors')}
            className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300 transform hover:scale-105 flex items-center"
          >
            <i className="fas fa-times-circle mr-2"></i>Batal
          </button>
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300 transform hover:scale-105 flex items-center"
          >
            <i className="fas fa-save mr-2"></i>{isEditMode ? 'Perbarui Penulis' : 'Tambah Penulis'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default AuthorForm;