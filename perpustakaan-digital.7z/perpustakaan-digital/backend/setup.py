import os
from setuptools import setup, find_packages

# Dapatkan direktori dari file setup.py ini
here = os.path.abspath(os.path.dirname(__file__))

# Daftar paket yang dibutuhkan oleh proyek Anda
# Ini harusnya cocok dengan yang ada di requirements.txt
requires = [
    'SQLAlchemy',
    'pyramid',
    'pyramid_debugtoolbar',
    'pyramid_tm',
    'waitress',
    'zope.sqlalchemy',
    'passlib',
    'pyjwt',
    'bcrypt',
    'pg8000',
    'transaction',
]

setup(
    name='project_name', # Pastikan ini cocok dengan nama folder proyek Anda (project_name)
    version='0.0.1', # Nomor versi proyek Anda
    description='Perpustakaan Digital Backend', # Deskripsi singkat proyek
    long_description='Backend for Perpustakaan Digital using Pyramid', # Deskripsi lebih panjang
    classifiers=[
        'Programming Language :: Python',
        'Framework :: Pyramid',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: WSGI :: Application',
    ],
    author='Talitha', # Ganti dengan nama Anda
    author_email='talitha.email@example.com', # Ganti dengan email Anda
    url='http://yourproject.com', # Ganti dengan URL proyek Anda jika ada
    keywords='web pyramid backend',
    packages=find_packages(), # Ini akan otomatis menemukan folder 'project_name' Anda
    include_package_data=True,
    zip_safe=False,
    install_requires=requires,
    entry_points={
        'paste.app_factory': [
            'main = project_name:main', # Ini menunjuk ke fungsi 'main' di dalam paket 'project_name'
        ],
        # Jika Anda memiliki script terpisah untuk inisialisasi DB di subfolder, bisa diaktifkan di sini
        # 'console_scripts': [
        #     'initialize_project_name_db = project_name.scripts.initializedb:main',
        # ],
    },
)