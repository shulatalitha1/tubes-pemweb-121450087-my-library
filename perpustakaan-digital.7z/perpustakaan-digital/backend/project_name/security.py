# backend/project_name/security.py

from pyramid.interfaces import IAuthenticationPolicy
from zope.interface import implementer
import jwt
import datetime
from passlib.context import CryptContext # <-- DITAMBAHKAN: Untuk hashing password

# Import untuk ACL (Access Control List)
from pyramid.security import Allow, Authenticated, Everyone, Deny # <-- DITAMBAHKAN: Untuk RootFactory ACL

# Kunci rahasia untuk JWT
# PASTIKAN INI ADA DAN SAMA DENGAN YANG DI __init__.py dan views.py
JWT_SECRET = '345678S' 

@implementer(IAuthenticationPolicy)
class JWTAuthenticationPolicy:
    """ Kebijakan autentikasi JWT kustom. """
    def __init__(self, secret, callback=None):
        self.secret = secret
        self.callback = callback
        # HTTP header default untuk token
        self.http_header = 'Authorization'
        self.token_type = 'Bearer'

    def authenticated_userid(self, request):
        """
        Mengembalikan ID pengguna jika request berisi kredensial autentikasi yang valid.
        Metode ini dipanggil oleh Pyramid untuk menentukan pengguna yang terautentikasi.
        """
        return self.unauthenticated_userid(request)

    def unauthenticated_userid(self, request):
        """ Mengambil ID pengguna dari token JWT. """
        auth_header = request.headers.get(self.http_header)
        if not auth_header:
            return None

        parts = auth_header.split()
        if len(parts) == 2 and parts[0].lower() == self.token_type.lower():
            token = parts[1]
            try:
                payload = jwt.decode(token, self.secret, algorithms=['HS256'])
                
                # Periksa masa berlaku token secara eksplisit
                if 'exp' in payload and datetime.datetime.utcnow() > datetime.datetime.fromtimestamp(payload['exp']):
                    # Token kedaluwarsa, tetapi kita tidak langsung mengeluarkan respons HTTP di sini.
                    # Pyramid akan menangani 401 jika userid adalah None.
                    return None 

                # Menggunakan 'user_id' seperti yang digunakan di fungsi generate_token
                return payload.get('user_id') 
            except jwt.ExpiredSignatureError:
                return None
            except jwt.InvalidTokenError:
                return None
            except Exception as e:
                print(f"Error decoding JWT in unauthenticated_userid: {e}")
                return None
        return None

    def effective_principals(self, request):
        """ Mengembalikan prinsipal yang efektif (ID pengguna dan grup) untuk request. """
        userid = self.authenticated_userid(request)
        if userid is None:
            return [Everyone] # Jika tidak terautentikasi, hanya Everyone
        
        principals = [Everyone, Authenticated, f'user:{userid}']
        
        if self.callback:
            user_principals = self.callback(userid, request)
            if user_principals:
                principals.extend(user_principals)
        return principals

    # Metode remember dan forget perlu menghasilkan headers yang valid untuk JWT
    def remember(self, request, userid, **kw):
        """Generate a new JWT token for the user and return headers."""
        # 'userid' di sini bisa jadi 'user_id' atau 'username' tergantung bagaimana Anda menyimpannya
        # Sesuaikan payload dengan data yang ingin Anda masukkan ke token
        payload = {
            'user_id': userid, # <-- PASTIKAN KONSISTEN DENGAN YANG DISIMPAN DI TOKEN
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1) # Token berlaku 1 jam
        }
        # Tambahkan peran (role) ke payload jika tersedia di `kw`
        if 'role' in kw:
            payload['role'] = kw['role']
        if 'username' in kw: # Tambahkan username jika diperlukan di token
            payload['username'] = kw['username']

        token = jwt.encode(payload, self.secret, algorithm='HS256')
        # Pyramid akan otomatis mengambil header ini dan menambahkannya ke respons
        return [('Authorization', f'Bearer {token}')] 
    
    def forget(self, request):
        """Forget the user (return headers to clear the token)."""
        # Untuk "melupakan", kita biasanya tidak perlu mengirim header khusus untuk JWT.
        # Token di sisi klien akan kedaluwarsa atau dihapus.
        # Bisa juga dengan mengirimkan token kosong atau instruksi untuk menghapus.
        return [] # Tidak ada header khusus untuk "melupakan" JWT dari sisi server

    def get_token_from_request(self, request):
        """Extract JWT token from request headers."""
        # Coba dapatkan token dari header Authorization (standar Bearer)
        auth_header = request.headers.get('Authorization', '')
        if auth_header.startswith('Bearer '):
            return auth_header[7:] # Hapus prefix 'Bearer '
        
        # Jika Anda juga mengirim melalui X-Auth-Token, tambahkan ini
        # return request.headers.get('X-Auth-Token') 
        return None # Jika tidak ada token di Authorization header

# --- FUNGSI UTILITY LAINNYA ---

# Fungsi untuk menghash dan memverifikasi password
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def hash_password(password):
    """
    Menghash password menggunakan bcrypt.
    """
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    """
    Memverifikasi password.
    """
    return pwd_context.verify(plain_password, hashed_password)

# Fungsi untuk menghasilkan token JWT (Ini yang hilang dan menyebabkan ImportError)
def generate_token(user_id, username, role, secret):
    """ Menghasilkan token JWT dengan user_id, username, dan role. """
    payload = {
        'user_id': user_id,
        'username': username,
        'role': role,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1) # Token berlaku 1 jam
    }
    return jwt.encode(payload, secret, algorithm='HS256')

# Fungsi callback untuk menemukan grup/peran pengguna (dijadikan alias groupfinder)
def get_user_groups(userid, request):
    """Fungsi callback untuk mendapatkan grup/peran pengguna."""
    auth_header = request.headers.get('Authorization')
    if auth_header and auth_header.startswith('Bearer '):
        token = auth_header.split(' ')[1]
        try:
            # Menggunakan JWT_SECRET global di sini
            payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
            role = payload.get('role')
            if role:
                return [f'role:{role}']
        except (jwt.ExpiredSignatureError, jwt.InvalidTokenError) as e:
            print(f"Error in get_user_groups: {e}")
            pass
    return []

# Alias untuk kompatibilitas ke belakang atau penggunaan yang lebih singkat
groupfinder = get_user_groups

# Kelas RootFactory untuk ACL (Ini juga hilang)
class RootFactory:
    """ Pabrik akar untuk ACL (Access Control List). """
    __acl__ = [
        (Allow, Everyone, 'view'),
        (Allow, Authenticated, 'authenticated_access'), # Contoh: Izinkan user terautentikasi mengakses sesuatu
        (Allow, 'role:admin', 'admin_access'),       # Contoh: Izinkan admin akses khusus
        (Allow, 'role:admin', 'edit'),               # Contoh: Izinkan admin mengedit
        (Deny, Everyone, 'secret_data'),             # Contoh: Tolak semua orang mengakses 'secret_data'
    ]

    def __init__(self, request):
        # 'request' di sini adalah instance Request, bukan objek autentikasi
        pass