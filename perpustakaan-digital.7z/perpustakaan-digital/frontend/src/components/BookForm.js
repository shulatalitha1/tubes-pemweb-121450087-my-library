import React, { useState, useEffect } from 'react';
import axios from '../api/axiosConfig';
import { useNavigate, useParams } from 'react-router-dom';

const BookForm = () => {
  const { id } = useParams(); // Untuk mode edit
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [isbn, setIsbn] = useState('');
  const [publicationYear, setPublicationYear] = useState('');
  const [authorId, setAuthorId] = useState('');
  const [authors, setAuthors] = useState([]); // Untuk dropdown penulis
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const isEditMode = Boolean(id);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Ambil daftar penulis
        const authorsResponse = await axios.get('/authors');
        setAuthors(authorsResponse.data);

        if (isEditMode) {
          // Ambil detail buku jika dalam mode edit
          const bookResponse = await axios.get(`/books/${id}`);
          const bookData = bookResponse.data;
          setTitle(bookData.title);
          setIsbn(bookData.isbn || '');
          setPublicationYear(bookData.publication_year || '');
          setAuthorId(bookData.author_id || '');
        }
      } catch (err) {
        console.error('Gagal mengambil data:', err);
        setError('Gagal memuat data. Silakan coba lagi.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, isEditMode]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const bookData = {
      title,
      isbn: isbn || null, // Kirim null jika kosong
      publication_year: publicationYear ? parseInt(publicationYear, 10) : null, // Kirim null jika kosong
      author_id: parseInt(authorId, 10),
    };

    try {
      if (isEditMode) {
        await axios.put(`/books/${id}`, bookData);
        setSuccessMessage('Buku berhasil diperbarui!');
      } else {
        await axios.post('/books', bookData);
        setSuccessMessage('Buku berhasil ditambahkan!');
        // Reset form setelah penambahan
        setTitle('');
        setIsbn('');
        setPublicationYear('');
        setAuthorId('');
      }
      setTimeout(() => navigate('/books'), 1500); // Kembali ke daftar setelah 1.5 detik
    } catch (err) {
      console.error('Gagal menyimpan buku:', err.response ? err.response.data : err.message);
      setError(err.response?.data || 'Gagal menyimpan buku. Pastikan semua kolom terisi dengan benar.');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-500"></div>
        <p className="ml-4 text-lg text-gray-700">Memuat formulir...</p>
      </div>
    );
  }

  if (error && !successMessage) {
    return <div className="text-red-600 text-center text-lg mt-8">{error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200 w-full max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">
        {isEditMode ? 'Edit Buku' : 'Tambah Buku Baru'}
      </h2>
      {successMessage && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded-md relative mb-4" role="alert">
          <strong className="font-bold">Berhasil!</strong>
          <span className="block sm:inline ml-2">{successMessage}</span>
        </div>
      )}
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md relative mb-4" role="alert">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline ml-2">{error}</span>
        </div>
      )}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className="block text-gray-700 text-sm font-medium mb-2">
            Judul Buku:
          </label>
          <input
            type="text"
            id="title"
            className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="isbn" className="block text-gray-700 text-sm font-medium mb-2">
            ISBN:
          </label>
          <input
            type="text"
            id="isbn"
            className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
            value={isbn}
            onChange={(e) => setIsbn(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="publicationYear" className="block text-gray-700 text-sm font-medium mb-2">
            Tahun Publikasi:
          </label>
          <input
            type="number"
            id="publicationYear"
            className="shadow-sm appearance-none border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
            value={publicationYear}
            onChange={(e) => setPublicationYear(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="author" className="block text-gray-700 text-sm font-medium mb-2">
            Penulis:
          </label>
          <select
            id="author"
            className="shadow-sm border rounded-md w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition duration-200"
            value={authorId}
            onChange={(e) => setAuthorId(e.target.value)}
            required
          >
            <option value="">Pilih Penulis</option>
            {authors.map((author) => (
              <option key={author.id} value={author.id}>
                {author.name}
              </option>
            ))}
          </select>
        </div>
        <div className="flex justify-end space-x-4 mt-6">
          <button
            type="button"
            onClick={() => navigate('/books')}
            className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300 transform hover:scale-105 flex items-center"
          >
            <i className="fas fa-times-circle mr-2"></i>Batal
          </button>
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300 transform hover:scale-105 flex items-center"
          >
            <i className="fas fa-save mr-2"></i>{isEditMode ? 'Perbarui Buku' : 'Tambah Buku'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BookForm;