import React, { useEffect, useState } from 'react';
import axios from '../api/axiosConfig';
import { Link } from 'react-router-dom';

const BookList = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      setLoading(true);
      const response = await axios.get('/books');
      setBooks(response.data);
      setError('');
    } catch (err) {
      console.error('Gagal mengambil buku:', err);
      setError('Gagal memuat daftar buku. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus buku ini?')) {
      try {
        await axios.delete(`/books/${id}`);
        fetchBooks(); // Muat ulang daftar buku setelah penghapusan
      } catch (err) {
        console.error('Gagal menghapus buku:', err);
        setError('Gagal menghapus buku. Silakan coba lagi.');
      }
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-indigo-500"></div>
        <p className="ml-4 text-lg text-gray-700">Memuat buku...</p>
      </div>
    );
  }

  if (error) {
    return <div className="text-red-600 text-center text-lg mt-8">{error}</div>;
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold text-gray-800">Daftar Buku</h2>
        <Link
          to="/books/add"
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md shadow-md transition duration-300 transform hover:scale-105 flex items-center"
        >
          <i className="fas fa-plus-circle mr-2"></i>Tambah Buku Baru
        </Link>
      </div>

      {books.length === 0 ? (
        <p className="text-center text-gray-600 text-lg py-10">Belum ada buku yang tersedia.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white border border-gray-300 rounded-lg">
            <thead className="bg-gray-100">
              <tr>
                <th className="py-3 px-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider rounded-tl-lg">Judul</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">ISBN</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Tahun Publikasi</th>
                <th className="py-3 px-4 text-left text-sm font-semibold text-gray-700 uppercase tracking-wider">Penulis</th>
                <th className="py-3 px-4 text-center text-sm font-semibold text-gray-700 uppercase tracking-wider rounded-tr-lg">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {books.map((book) => (
                <tr key={book.id} className="border-b border-gray-200 last:border-b-0 hover:bg-gray-50 transition duration-150">
                  <td className="py-3 px-4 text-gray-800">{book.title}</td>
                  <td className="py-3 px-4 text-gray-600">{book.isbn || '-'}</td>
                  <td className="py-3 px-4 text-gray-600">{book.publication_year || '-'}</td>
                  <td className="py-3 px-4 text-gray-800">{book.author_name || 'Tidak Diketahui'}</td>
                  <td className="py-3 px-4 text-center">
                    <Link
                      to={`/books/edit/${book.id}`}
                      className="bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded-md text-sm mr-2 transition duration-200"
                      title="Edit Buku"
                    >
                      <i className="fas fa-edit"></i>
                    </Link>
                    <button
                      onClick={() => handleDelete(book.id)}
                      className="bg-red-500 hover:bg-red-600 text-white py-1 px-3 rounded-md text-sm transition duration-200"
                      title="Hapus Buku"
                    >
                      <i className="fas fa-trash-alt"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default BookList;