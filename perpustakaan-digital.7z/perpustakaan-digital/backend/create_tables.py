# backend/create_tables.py

import os
import sys
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from paste.deploy.loadwsgi import appconfig

project_root = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(project_root) == 'backend':
    sys.path.insert(0, os.path.join(project_root, 'project_name'))
else:
    sys.path.insert(0, project_root)

from project_name.models import Base, Book, Author

config_uri = 'development.ini'

def initialize_database():
    print("Memulai inisialisasi database menggunakan konfigurasi dari 'development.ini'...")
    try:
        full_config_uri = 'config:' + config_uri

        settings = appconfig(full_config_uri, relative_to=os.path.dirname(os.path.abspath(__file__)))

        database_url = settings.get('sqlalchemy.url')
        if not database_url:
            raise ValueError("Tidak ditemukan 'sqlalchemy.url' dalam konfigurasi database.")

        engine = create_engine(database_url)

        Base.metadata.create_all(engine)
        print("Tabel database berhasil dibuat atau diperbarui.")

        Session = sessionmaker(bind=engine)
        session = Session()

        author_lookup = {} 

        # Daftar penulis yang komprehensif, gabungan dari yang lama dan yang baru
        # Pastikan semua nama penulis yang Anda inginkan ada di sini.
        all_authors_data = [
            # Penulis Lama (sesuai daftar Anda sebelumnya)
            {"name": "Andrea Hirata", "bio": "Penulis novel 'Laskar Pelangi'."},
            {"name": "Tere Liye", "bio": "Penulis fiksi populer Indonesia."},
            {"name": "Pidi Baiq", "bio": "Penulis novel 'Dilan'."},
            {"name": "Eka Kurniawan", "bio": "Penulis novel 'Cantik Itu Luka'."},
            {"name": "Pramoedya Ananta Toer", "bio": "Sastrawan besar Indonesia."},
            {"name": "Gosho Aoyama", "bio": "Mangaka seri Detektif Conan."},
            {"name": "Hergé", "bio": "Pencipta komik Petualangan Tintin."},
            {"name": "Henry Manampiring", "bio": "Penulis 'Filosofi Teras'."},
            {"name": "Stephen King", "bio": "Master novel horor dan thriller."},
            {"name": "Agatha Christie", "bio": "Ratu kejahatan dan misteri."},
            {"name": "Fiersa Besari", "bio": "Musisi dan penulis petualangan."},
            {"name": "Boy Candra", "bio": "Penulis fiksi romansa remaja."},
            {"name": "W.S. Rendra", "bio": "Penyair dan dramawan Indonesia."},
            {"name": "Sapardi Djoko Damono", "bio": "Penyair terkenal Indonesia."},
            {"name": "Dee Lestari", "bio": "Penulis dan musisi Indonesia."},
            {"name": "Habiburrahman El Shirazy", "bio": "Penulis novel Islami populer."},
            {"name": "R.A. Kartini", "bio": "Pelopor kebangkitan perempuan pribumi."},
            {"name": "Soekarno", "bio": "Presiden pertama Republik Indonesia."},
            {"name": "Haruki Murakami", "bio": "Penulis novel realisme magis dari Jepang."},
            {"name": "George Orwell", "bio": "Penulis '1984' dan 'Animal Farm'."},
            {"name": "Jane Austen", "bio": "Penulis novel romansa klasik Inggris."},
            {"name": "Paulo Coelho", "bio": "Penulis novel spiritual asal Brasil."},
            {"name": "Mark Manson", "bio": "Penulis 'Sebuah Seni untuk Bersikap Bodo Amat'."}, 

            # --- PENULIS YANG ANDA MINTA UNTUK DITAMBAHKAN ---
            {"name": "Ziggy Zezsyazeoviennazabrizkie", "bio": "Penulis fiksi ilmiah dan fantasi Indonesia."},
            {"name": "Ary Nilandari", "bio": "Dikenal dengan karya-karya fiksi anak dan remaja."},
            {"name": "J.K. Rowling", "bio": "Penulis seri Harry Potter."}, # Ini sudah ada, tapi memastikan ada bio
            {"name": "Jessica Townsend", "bio": "Penulis seri Nevermoor."},
            {"name": "Kathryn Littlewood", "bio": "Penulis seri Bake Shop Mysteries."},
            {"name": "Mo Xiang Tong Xiu", "bio": "Penulis novel dan manhua BL (Boys' Love) terkenal dari Tiongkok."},
            {"name": "Rou Bao Bu Chi Rou", "bio": "Penulis novel BL asal Tiongkok. Karyanya termasuk The Husky and His White Cat Shizun."}, 
            {"name": "Stephanie Garber", "bio": "Penulis seri Caraval."},
            {"name": "Dan Brown", "bio": "Penulis novel thriller konspirasi seperti The Da Vinci Code."},
            {"name": "Leila S. Chudori", "bio": "Jurnalis dan penulis ternama Indonesia."} # Ini juga sudah ada, tapi memastikan ada bio
        ]

        print("Memproses data penulis...")
        for author_data in all_authors_data:
            existing_author = session.query(Author).filter_by(name=author_data['name']).first()
            if not existing_author:
                author_obj = Author(name=author_data['name'], bio=author_data.get('bio', ''))
                session.add(author_obj)
                print(f"  Menambahkan penulis baru: {author_obj.name}")
                author_lookup[author_data['name']] = author_obj
            else:
                # Update bio jika ingin
                # existing_author.bio = author_data.get('bio', existing_author.bio)
                author_lookup[author_data['name']] = existing_author
                print(f"  Penulis '{existing_author.name}' sudah ada.")

        session.commit() # Commit penulis agar mereka memiliki ID
        print("Data penulis berhasil ditambahkan atau diperbarui.")

        # --- Tambahkan data buku dummy jika belum ada ---
        # Jika Anda ingin mengulang data buku setiap kali skrip dijalankan,
        # Anda bisa menghapus `if not session.query(Book).first():`
        if not session.query(Book).first(): 
            print("Menambahkan data buku dummy...")
            dummy_books_data = [
                {"title": "Detektif Conan: Kasus Pembunuhan", "author_name": "Gosho Aoyama", "publication_year": 1994, "isbn": "978-602-00-1234-5"},
                {"title": "Petualangan Tintin: Rahasia Unicorn", "author_name": "Hergé", "publication_year": 1943, "isbn": "978-979-11-2345-6"},
                {"title": "Harry Potter dan Batu Bertuah", "author_name": "J.K. Rowling", "publication_year": 1997, "isbn": "978-0-7475-3269-9"},
                {"title": "Laskar Pelangi", "author_name": "Andrea Hirata", "publication_year": 2005, "isbn": "978-979-3062-79-1"},
                {"title": "Filosofi Teras", "author_name": "Henry Manampiring", "publication_year": 2018, "isbn": "978-602-00-1111-1"},
                {"title": "Bumi", "author_name": "Tere Liye", "publication_year": 2014, "isbn": "978-602-03-0808-8"},
                {"title": "Dilan 1990", "author_name": "Pidi Baiq", "publication_year": 2014, "isbn": "978-602-78-9000-0"},
                {"title": "Cantik Itu Luka", "author_name": "Eka Kurniawan", "publication_year": 2004, "isbn": "978-979-91-0306-3"},
                {"title": "Pulang", "author_name": "Leila S. Chudori", "publication_year": 2012, "isbn": "978-979-91-0498-5"},
                {"title": "Bumi Manusia", "author_name": "Pramoedya Ananta Toer", "publication_year": 1980, "isbn": "978-979-91-0504-3"},
                {"title": "It", "author_name": "Stephen King", "publication_year": 1986, "isbn": "978-0-451-16951-8"},
                {"title": "And Then There Were None", "author_name": "Agatha Christie", "publication_year": 1939, "isbn": "978-0-00-713093-6"},
                {"title": "Garis Waktu", "author_name": "Fiersa Besari", "publication_year": 2016, "isbn": "978-602-03-3401-8"},
                {"title": "Sebuah Seni untuk Bersikap Bodo Amat", "author_name": "Mark Manson", "publication_year": 2016, "isbn": "978-602-03-3631-9"},
                {"title": "1984", "author_name": "George Orwell", "publication_year": 1949, "isbn": "978-0-452-28423-4"},
                {"title": "Pride and Prejudice", "author_name": "Jane Austen", "publication_year": 1813, "isbn": "978-0-14-143951-8"},
                {"title": "The Name of the Wind", "author_name": "Patrick Rothfuss", "publication_year": 2007, "isbn": "978-0756404741"}, # Contoh buku lain

                # --- BUKU BARU UNTUK PENULIS YANG BARU DITAMBAHKAN/DIPASTIKAN ---
                {"title": "Semua Ikan di Langit", "author_name": "Ziggy Zezsyazeoviennazabrizkie", "publication_year": 2017, "isbn": "978-6020336203"},
                {"title": "Putri Tidur dan Burung Pipit", "author_name": "Ary Nilandari", "publication_year": 2015, "isbn": "978-6020317370"},
                {"title": "Harry Potter and the Chamber of Secrets", "author_name": "J.K. Rowling", "publication_year": 1998, "isbn": "978-0747538493"},
                {"title": "Nevermoor: The Wundersmith", "author_name": "Jessica Townsend", "publication_year": 2018, "isbn": "978-0316462724"},
                {"title": "Gingerbread", "author_name": "Kathryn Littlewood", "publication_year": 2011, "isbn": "978-0062007421"},
                {"title": "Grandmaster of Demonic Cultivation (Mo Dao Zu Shi)", "author_name": "Mo Xiang Tong Xiu", "publication_year": 2016, "isbn": "978-1648279096"},
                {"title": "The Husky and His White Cat Shizun (2ha)", "author_name": "Rou Bao Bu Chi Rou", "publication_year": 2017, "isbn": "978-1648279768"},
                {"title": "Legendary", "author_name": "Stephanie Garber", "publication_year": 2018, "isbn": "978-1250052971"},
                {"title": "Angels & Demons", "author_name": "Dan Brown", "publication_year": 2000, "isbn": "978-0743477156"},
                {"title": "Laut Bercerita", "author_name": "Leila S. Chudori", "publication_year": 2017, "isbn": "978-6020353491"},
            ]

            books_to_add = []
            for book_data in dummy_books_data:
                # Pastikan buku belum ada sebelum ditambahkan
                existing_book = session.query(Book).filter_by(isbn=book_data['isbn']).first()
                if not existing_book:
                    author_obj = author_lookup.get(book_data['author_name'])
                    if author_obj:
                        new_book = Book(
                            title=book_data['title'],
                            author=author_obj, # Langsung kaitkan objek Author
                            publication_year=book_data['publication_year'],
                            isbn=book_data['isbn']
                        )
                        books_to_add.append(new_book)
                    else:
                        print(f"Peringatan: Penulis '{book_data['author_name']}' tidak ditemukan untuk buku '{book_data['title']}'. Buku tidak akan ditambahkan.")
                else:
                    print(f"  Buku '{existing_book.title}' (ISBN: {existing_book.isbn}) sudah ada.")


            session.add_all(books_to_add)
            session.commit()
            print(f"{len(books_to_add)} buku dummy berhasil ditambahkan.")
        else:
            print("Data buku sudah ada.")

        session.close()

    except Exception as e:
        print(f"Terjadi kesalahan saat inisialisasi database: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    initialize_database()