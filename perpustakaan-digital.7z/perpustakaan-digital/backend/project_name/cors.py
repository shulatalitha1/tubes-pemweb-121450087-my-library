# project_name/cors.py

def add_cors_headers_response_callback(request, response):
    """Add CORS headers to all responses"""
    response.headers.update({
        'Access-Control-Allow-Origin': 'http://localhost:3000',
        'Access-Control-Allow-Methods': 'POST,GET,DELETE,PUT,OPTIONS',
        'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
        'Access-Control-Allow-Credentials': 'true',
        'Access-Control-Max-Age': '1728000',
    })


def cors_options_view(request):
    """Handle preflight OPTIONS requests"""
    response = request.response
    if request.method == 'OPTIONS':
        response.headers.update({
            'Access-Control-Allow-Origin': 'http://localhost:3000',
            'Access-Control-Allow-Methods': 'POST,GET,DELETE,PUT,OPTIONS',
            'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
            'Access-Control-Allow-Credentials': 'true',
            'Access-Control-Max-Age': '1728000',
        })
        response.status_int = 200
    return response


def includeme(config):
    """Configure CORS"""
    config.add_response_callback(add_cors_headers_response_callback)
    config.add_view(cors_options_view, route_name='cors-options-catchall', request_method='OPTIONS')
    config.add_route('cors-options-catchall', '/{path:.*}', request_method='OPTIONS')