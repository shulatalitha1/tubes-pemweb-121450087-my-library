# backend/project_name/__init__.py

from pyramid.config import Configurator
from pyramid.authorization import ACLAuthorizationPolicy
from pyramid.events import NewRequest # Hanya import NewRequest, bukan subscriber di sini

# Anda mungkin perlu mengimpor ini jika belum ada (sesuai kebutuhan Anda)
from .security import JWTAuthenticationPolicy, groupfinder, JWT_SECRET, RootFactory 

def main(global_config, **settings):
    """ This function returns a Pyramid WSGI application.
    """
    with Configurator(settings=settings) as config:
        config.include('pyramid_mako')

        # Kebijakan autentikasi dan otorisasi tetap dinonaktifkan (sesuai keputusan)
        # auth_policy = JWTAuthenticationPolicy(
        #     secret=JWT_SECRET,
        #     callback=groupfinder
        # )
        # authz_policy = ACLAuthorizationPolicy()
        # config.set_authentication_policy(auth_policy)
        # config.set_authorization_policy(authz_policy)

        config.set_root_factory(RootFactory)

        # DAFTARKAN SUBSCRIBER CORS DARI VIEWS.PY
        # Pastikan ini ada dan mengarah ke views.add_cors_headers
        config.add_subscriber('.views.add_cors_headers', NewRequest)

        # --- Rute Aplikasi - SEKARANG DENGAN AWALAN '/api' ---
        config.add_route('home', '/') 
        config.add_route('status', '/api/status') 
        config.add_route('protected', '/api/protected') 

        # Rute untuk Buku (CRUD lengkap)
        config.add_route('books', '/api/books') 
        config.add_route('book_detail', '/api/books/{id}')
        config.add_route('borrow_book', '/api/books/{id}/borrow')
        config.add_route('return_book', '/api/books/{id}/return')

        # Rute untuk Users
        config.add_route('users', '/api/users') 
        config.add_route('user_detail', '/api/users/{id}') 

        # Rute untuk Authors (CRUD lengkap)
        config.add_route('authors', '/api/authors') 
        config.add_route('author_detail', '/api/authors/{id}') 

        config.scan('.') # Ini yang akan menemukan @view_config dan @subscriber di views.py

    return config.make_wsgi_app()